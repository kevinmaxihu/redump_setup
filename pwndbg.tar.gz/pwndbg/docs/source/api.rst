API
========

``pwndbg`` provides a very rich programmatic API for interaction.

.. toctree::
    :maxdepth: 3
    :glob:

    api/*
