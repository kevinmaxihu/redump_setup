:mod:`pwndbg.ida` --- pwndbg.ida
=============================================

.. automodule:: pwndbg.ida
    :members:
