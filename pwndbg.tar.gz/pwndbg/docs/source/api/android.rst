:mod:`pwndbg.android` --- pwndbg.android
=============================================

.. automodule:: pwndbg.android
    :members:
