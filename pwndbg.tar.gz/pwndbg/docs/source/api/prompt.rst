:mod:`pwndbg.prompt` --- pwndbg.prompt
=============================================

.. automodule:: pwndbg.prompt
    :members:
