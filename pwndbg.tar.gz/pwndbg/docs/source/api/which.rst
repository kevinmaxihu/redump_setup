:mod:`pwndbg.which` --- pwndbg.which
=============================================

.. automodule:: pwndbg.which
    :members:
