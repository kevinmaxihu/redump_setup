.. autoprogram:: pwndbg.commands.hexdump:parser
   :prog: hexdump
