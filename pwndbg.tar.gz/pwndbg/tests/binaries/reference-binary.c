#include <stdio.h>

void foo() {}

int main() {
    puts("Hello world");
    foo();
}
